# 3-Layer System Master Dashboard

*Last Compiled: 2026-05-23 16:09:35 (Reference Date: 2026-05-23)*

## Active Mission Tracking Ledger

| Mission ID | Status | Priority | Submission Deadline | T-1 Lockout Freeze | Next Action |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `2026_Test_Proposal` | `active` | `standard` | **2026-05-30** | `2026-05-29` | N/A |
| `sfu_farley_visiting_scholar` | `pipeline_eval` | `high` | **2026-05-31** | `2026-05-30` | Initiate formal match inquiry with Dr. Guillaume Blanc and Dr. Steeve Mongrain before review starts on May 4. |
| **`2026_Test_Project` ⚠️** | **`active`** | **`standard`** | **2026-06-01** | **`2026-05-22`** | **N/A** |
| `2026_global_development_Norwhich` | `active` | `standard` | **2026-06-01** | `2026-05-31` | N/A |
| `2026_LSE_Fellow` | `active` | `standard` | **2026-06-12** | `2026-06-11` | N/A |
| `oxford_osga_dl` | `pipeline_eval` | `high` | **2026-06-15** | `2026-06-14` | Pivot CV and Supporting Statement to foreground qualitative research methods, comparative area methodologies, and transnational structural political economy. |
| `jnu_iesr_irf` | `pipeline_eval` | `high` | **2026-12-31** | `2026-12-30` | Align contemporary structural macro-political economy with the JNU quantitative/empirical research environment and draft the 3-year Research Statement. |

## Pending Logistics Ledger

| Urgency | Task | Description | Source Log |
| --- | --- | --- | --- |
