---
system_layer: 03_Outer
project_id: "2026_Test_Project"
status: active
deadlines:
  portal_submission: 2026-06-01
  t_minus_1_freeze: 2026-05-22
ai_engagement:
  allowance: restricted
  gatekeeper_prompt: "03_Outer_Layer/System_Prompts.md"
conceptual_anchor: "02_Inner_Layer/Conceptual_Notes/Anchor_Note.md"
---
# Test Project Application Draft

This is a draft of the application. Since we are past the T-1 freeze date, any attempts to modify this prose must be flagged and locked.
